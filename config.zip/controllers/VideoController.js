const formidable = require('formidable');

// import models
const { userModel } = require('../models/UserModel') 

const { uploadFile, downloadFile } = require('../lib/Firebase');

class SaveVideo{
    // save video to firebase and get the url

    static async postVideo(req, res) {
        try {
            const form = new formidable.IncomingForm();

            form.parse(req, async (err, fields, files) => {
                const id = Number(req.query.id)
                    console.log(files)
                // upload video to Firebase
                await uploadFile(files.video.filepath, `video/user${id}`);

                // get the Firebase url
                const fileUrl = await downloadFile(`video/user${id}`);

                // save the URL to database
                await userModel.saveVideo(id, fileUrl[0]); 
                
                // get updated data list
                setTimeout(async function() {
                    const userdata = await userModel.getVideo(id, '')
                    res.status(200).json({status: "success", data: {video: userdata.video}})
                }, 2000)               
            })
            
        } catch (error) {
            console.log(error)
            res.render('error', { error, message: 'SAVE FILE ERROR'})
        }
    }

        // Get user video URL
        static async getUserVideoUrl(req, res) {
            try {
                const userId = Number(req.params.id);
    
                // Get video URL for the user
                const videoUrl = await ProfilePageModel.getVideoUrl(userId);
    
                // Send the video URL to the client
                return res.json({ status: 'success', videoUrl });
            } catch (error) {
                console.log(error);
                return res.status(500).send('Internal Server Error!');
            }
        }
}

module.exports = {SaveVideo}